DB Cache
opencart module
version 1.16.08.10
———————

VQMOD required

Caches db sql queries to improve perfomance up to 10 times.
Automatically drop affected cache entries after any modification operation: insert/update/delete

CHANGES:
1.16.08.10:
	- Performance is boosted up - db cache kernel is optimized
	- Module settings - Cache Timeout Seconds to set for cache entries and Module Status - you could just disable db caching at any moment then turn on again
	- Clear DB Cache button is added to Admin System menu
	- Small bugs are fixed

Installation:
——————-
1. Copy upload folder content to the root of your site.
2. Install DB Cache module
3. Enjoy perfomance boost

tested on opencart 1.5.6.3

PN Solutions http://pnsols.com 2016
info@pnsols.com
