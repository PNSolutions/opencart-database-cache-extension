<?php
// Heading
$_['heading_title']	= 'DB Cache';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройки сохранены!';

$_['text_tab_general']		= 'Настройки';
$_['entry_cacheTimeoutSeconds'] = 'Таймаут Кэша, секунды';
$_['entry_status']        = 'Статус:';

$_['text_homepage']		= 'Сайт продукта';
// Error
$_['error_permission']		= 'Доступ запрещен!';
$_['error_cacheTimeoutSeconds']		= 'Таймаут Кэша должен быть больше 0 секунд!';