<?php
// Heading
$_['heading_title']	= 'DB Cache';

// Text
$_['text_module']		= 'Modules';
$_['text_success']		= 'Settings saved!';

$_['text_tab_general']		= 'General';
$_['entry_cacheTimeoutSeconds'] = 'Cache Timeout Seconds';
$_['entry_status']        = 'Status:';

$_['text_homepage']		= 'Home Page';

// Error
$_['error_permission']		= 'Premission denied!';
$_['error_cacheTimeoutSeconds']		= 'Cache Timeout Seconds must be greater 0!';