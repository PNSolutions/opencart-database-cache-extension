OpenCart DB Cache:
———————

VQMOD

Caches db sql queries to improve perfomance to 10 times.
Automatically drop affected cache entries after any modification operation: insert/update/delete



Installation:
——————-
1. Copy upload folder content to the root of your site.
2. Enjoy perfomance boost

PN Solutions http://pnsols.com 2016
